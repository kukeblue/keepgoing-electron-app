// 程序运行的各种参数

interface IState {
    runningPyProcess: {}
}
export const AppChildProcess = {
}
const state:IState = {
    runningPyProcess: {
    }
}

export default state
